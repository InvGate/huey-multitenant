__author__ = 'InvGate Discover Team'
__license__ = 'MIT'
__version__ = '1.0.0'